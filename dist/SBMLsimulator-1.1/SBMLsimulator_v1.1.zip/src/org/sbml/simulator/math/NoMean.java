/*
 * $Id: NoMean.java 917 2014-01-09 22:32:32Z draeger $
 * $URL: https://rarepos.cs.uni-tuebingen.de/svn-path/SBMLsimulator/branches/1.0-series/src/org/sbml/simulator/math/NoMean.java $
 * ---------------------------------------------------------------------
 * This file is part of SBMLsimulator, a Java-based simulator for models
 * of biochemical processes encoded in the modeling language SBML.
 *
 * Copyright (C) 2007-2014 by the University of Tuebingen, Germany.
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation. A copy of the license
 * agreement is provided in the file named "LICENSE.txt" included with
 * this software distribution and also available online as
 * <http://www.gnu.org/licenses/lgpl-3.0-standalone.html>.
 * ---------------------------------------------------------------------
 */
package org.sbml.simulator.math;

/**
 * 
 * @author Roland Keller
 * @version $Rev: 917 $
 */
// TODO: What is NoMean???
public class NoMean extends MeanFunction {
  
  /**
   * Generated serial version identifier.
   */
  private static final long serialVersionUID = 7739137402966833880L;

  /*
   * (non-Javadoc)
   * @see org.sbml.simulator.math.MeanFunction#computeMean(double[])
   */
  public double computeMean(double... values) {
    double result = 0d;
    for (double value : values) {
      result += value;
    }
    return result;
  }
  
}
