/*
 * $Id: MetaDataset.java 788 2013-01-04 11:46:00Z draeger $
 * $URL: https://rarepos.cs.uni-tuebingen.de/svn-path/SBMLsimulator/branches/1.0-series/src/org/sbml/simulator/gui/plot/MetaDataset.java $
 * ---------------------------------------------------------------------
 * This file is part of SBMLsimulator, a Java-based simulator for models
 * of biochemical processes encoded in the modeling language SBML.
 *
 * Copyright (C) 2007-2013 by the University of Tuebingen, Germany.
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation. A copy of the license
 * agreement is provided in the file named "LICENSE.txt" included with
 * this software distribution and also available online as
 * <http://www.gnu.org/licenses/lgpl-3.0-standalone.html>.
 * ---------------------------------------------------------------------
 */
package org.sbml.simulator.gui.plot;

import org.jfree.data.xy.XYDataset;

/**
 * @author Andreas Dr&auml;ger
 * @version $Rev: 788 $
 * @since 1.0
 */
public interface MetaDataset extends XYDataset {
	
	/**
	 * Returns the identifier of the given series.
	 * 
	 * @param series
	 * @return
	 */
	public String getSeriesIdentifier(int series);
	
	/**
	 * 
	 * @param identifier
	 * @return
	 */
	public int getSeriesIndex(String identifier);
	
}
