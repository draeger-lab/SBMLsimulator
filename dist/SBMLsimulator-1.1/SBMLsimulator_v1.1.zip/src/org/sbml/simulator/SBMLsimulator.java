/*
 * $Id: SBMLsimulator.java 890 2013-04-25 12:25:10Z draeger $
 * $URL: https://rarepos.cs.uni-tuebingen.de/svn-path/SBMLsimulator/branches/1.0-series/src/org/sbml/simulator/SBMLsimulator.java $
 * ---------------------------------------------------------------------
 * This file is part of SBMLsimulator, a Java-based simulator for models
 * of biochemical processes encoded in the modeling language SBML.
 *
 * Copyright (C) 2007-2013 by the University of Tuebingen, Germany.
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation. A copy of the license
 * agreement is provided in the file named "LICENSE.txt" included with
 * this software distribution and also available online as
 * <http://www.gnu.org/licenses/lgpl-3.0-standalone.html>.
 * ---------------------------------------------------------------------
 */
package org.sbml.simulator;

import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import jp.sbi.garuda.platform.commons.exception.NetworkException;

import org.sbml.optimization.problem.EstimationOptions;
import org.sbml.simulator.gui.SimulatorUI;
import org.sbml.simulator.gui.plot.PlotOptions;
import org.sbml.simulator.io.SimulatorIOOptions;
import org.sbml.simulator.math.QualityMeasure;
import org.simulator.math.odes.AbstractDESSolver;

import de.zbit.AppConf;
import de.zbit.Launcher;
import de.zbit.UserInterface;
import de.zbit.garuda.BackendNotInitializedException;
import de.zbit.garuda.GarudaOptions;
import de.zbit.garuda.GarudaSoftwareBackend;
import de.zbit.gui.BaseFrame;
import de.zbit.gui.GUIOptions;
import de.zbit.gui.GUITools;
import de.zbit.io.csv.CSVOptions;
import de.zbit.util.ResourceManager;
import de.zbit.util.prefs.KeyProvider;
import de.zbit.util.prefs.SBProperties;

/**
 * Start program for {@link SBMLsimulator}.
 * 
 * @author Andreas Dr&auml;ger
 * @author Roland Keller
 * @date 2010-09-01
 * @version $Rev: 890 $
 * @since 1.0
 */
@SuppressWarnings("unchecked")
public class SBMLsimulator extends Launcher {

	/**
	 * Generated serial version identifier.
	 */
	private static final long serialVersionUID = -6519145035944241806L;
	
	/**
	 * Localization support.
	 */
	public static final transient ResourceBundle bundle = ResourceManager.getBundle("org.sbml.simulator.locales.Simulator");

	/**
	 * The logger for this class.
	 */
	public static final transient Logger logger = Logger
			.getLogger(SBMLsimulator.class.getName());

	//	/**
	//	 * The possible location of this class in a jar file if used in plug-in
	//	 * mode.
	//	 */
	//	public static final String JAR_LOCATION = "plugin"
	//			+ StringUtil.fileSeparator();

	/**
	 * The package where all mathematical functions, in particular distance
	 * functions, are located.
	 */
	public static final String MATH_PACKAGE = "org.sbml.simulator.math";

	/**
	 * The package where all ODE solvers are assumed to be located.
	 */
	public static final String SOLVER_PACKAGE = "org.simulator.math.odes";

	/**
	 * An array of all available implementations of distance functions to judge
	 * the quality of a simulation based on parameter and initial value settings.
	 */
	private static final Class<QualityMeasure> AVAILABLE_QUALITY_MEASURES[];

	/**
	 * An array of all available ordinary differential equation solvers.
	 */
	private static final Class<AbstractDESSolver> AVAILABLE_SOLVERS[];

	static {
		int i;
		//	AVAILABLE_QUALITY_MEASURES = Reflect.getAllClassesInPackage(MATH_PACKAGE,
		//	true, true, QualityMeasure.class, JAR_LOCATION, true);
		String classes[] = new String[] {
				"org.sbml.simulator.math.EuclideanDistance",
				"org.sbml.simulator.math.ManhattanDistance",
				"org.sbml.simulator.math.N_Metric",
				"org.sbml.simulator.math.PearsonCorrelation",
				"org.sbml.simulator.math.RelativeEuclideanDistance",
				"org.sbml.simulator.math.RelativeManhattanDistance",
				"org.sbml.simulator.math.RelativeSquaredError",
		"org.sbml.simulator.math.Relative_N_Metric" };
		AVAILABLE_QUALITY_MEASURES = new Class[classes.length];
		for (i = 0; i < classes.length; i++) {
			try {
				AVAILABLE_QUALITY_MEASURES[i] = (Class<QualityMeasure>) Class.forName(classes[i]);
			} catch (ClassNotFoundException exc) {
				logger.severe(exc.getLocalizedMessage());
			}
		}

		// AVAILABLE_SOLVERS = Reflect.getAllClassesInPackage(SOLVER_PACKAGE, true,
		//   true, AbstractDESSolver.class, JAR_LOCATION, true);
		classes = new String[] { 
				"org.simulator.math.odes.AdamsBashforthSolver",
				"org.simulator.math.odes.AdamsMoultonSolver",
				"org.simulator.math.odes.DormandPrince54Solver",
				"org.simulator.math.odes.DormandPrince853Solver",
				"org.simulator.math.odes.EulerMethod",
				"org.simulator.math.odes.GraggBulirschStoerSolver",
				"org.simulator.math.odes.HighamHall54Solver",
				"org.simulator.math.odes.RosenbrockSolver",
		"org.simulator.math.odes.RungeKutta_EventSolver" };
		AVAILABLE_SOLVERS = new Class[classes.length];
		for (i = 0; i < classes.length; i++) {
			try {
				AVAILABLE_SOLVERS[i] = (Class<AbstractDESSolver>) Class.forName(classes[i]);
			} catch (ClassNotFoundException exc) {
				logger.severe(exc.getLocalizedMessage());
			}
		}
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static List<Class> getAvailableQualityMeasureClasses() {
		List<Class> qualityList = new ArrayList<Class>(
				AVAILABLE_QUALITY_MEASURES.length);
		for (Class<? extends QualityMeasure> qualityMeasureClass : AVAILABLE_QUALITY_MEASURES) {
			try {
				qualityList.add(qualityMeasureClass);
			} catch (Exception e) {
				logger.warning(e.getLocalizedMessage());
			}
		}
		return qualityList;
	}

	/**
	 * @return
	 */
	public static List<String> getAvailableQualityMeasureClassNames() {
		List<String> qualityList = new ArrayList<String>(
				AVAILABLE_QUALITY_MEASURES.length);
		for (Class<?> qualityMeasureClass : AVAILABLE_QUALITY_MEASURES) {
			try {
				qualityList.add(qualityMeasureClass.getName());
			} catch (Exception e) {
				logger.warning(e.getLocalizedMessage());
			}
		}
		return qualityList;
	}

	/**
	 * @return
	 */
	public static final Class<QualityMeasure>[] getAvailableQualityMeasures() {
		return AVAILABLE_QUALITY_MEASURES;
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static List<Class> getAvailableSolverClasses() {
		List<Class> solverList = new ArrayList<Class>(AVAILABLE_SOLVERS.length);
		for (Class<AbstractDESSolver> solverClass : AVAILABLE_SOLVERS) {
			try {
				solverList.add(solverClass);
			} catch (Exception e) {
				logger.warning(e.getLocalizedMessage());
			}
		}
		return solverList;
	}

	/**
	 * 
	 * @return
	 */
	public static Class<AbstractDESSolver>[] getAvailableSolvers() {
		return AVAILABLE_SOLVERS;
	}

	/**
	 * 
	 * @param args
	 * @throws IOException 
	 * @throws HeadlessException 
	 */
	public static void main(String args[]) {
		new SBMLsimulator(args);
	}

	/**
	 * 
	 * @param args
	 */
	public SBMLsimulator(String[] args) {
		super(args);
	}

	/**
	 * 
	 */
	public SBMLsimulator() {
		super();
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#commandLineMode(de.zbit.AppConf)
	 */
	public void commandLineMode(AppConf appConf) {
		String openFile = null;
		SBProperties props = appConf.getCmdArgs();
		if (props.containsKey(SimulatorIOOptions.SBML_INPUT_FILE)) {
			openFile = props.get(SimulatorIOOptions.SBML_INPUT_FILE).toString();
		}
		String timeSeriesFile = null;
		if (props.containsKey(SimulatorIOOptions.TIME_SERIES_FILE)) {
			timeSeriesFile = props.get(SimulatorIOOptions.TIME_SERIES_FILE)
					.toString();
		}

		if (openFile != null) {
			CommandLineManager commandLineManager = new CommandLineManager(openFile,
					timeSeriesFile, appConf);
			commandLineManager.run();
		} else {
			logger.fine(MessageFormat.format(
					getResources().getString("INCOMPLETE_CMD_ARG_LIST"),
					getAppName(), getVersionNumber()));

		}
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getAppName()
	 */
	public String getAppName() {
		return getClass().getSimpleName();
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getCmdLineOptions()
	 */
	public List<Class<? extends KeyProvider>> getCmdLineOptions() {
		List<Class<? extends KeyProvider>> defAndKeys = new ArrayList<Class<? extends KeyProvider>>(6);
		defAndKeys.add(SimulatorIOOptions.class);
		defAndKeys.add(SimulationOptions.class);
		defAndKeys.add(EstimationOptions.class);
		defAndKeys.add(GUIOptions.class);
		defAndKeys.add(PlotOptions.class);
		defAndKeys.add(CSVOptions.class);
		defAndKeys.add(GarudaOptions.class);
		return defAndKeys;
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getInteractiveOptions()
	 */
	public List<Class<? extends KeyProvider>> getInteractiveOptions() {
		List<Class<? extends KeyProvider>> defAndKeys = new ArrayList<Class<? extends KeyProvider>>(5);
		defAndKeys.add(SimulationOptions.class);
		defAndKeys.add(EstimationOptions.class);
		defAndKeys.add(PlotOptions.class);
		return defAndKeys;
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getLogPackages()
	 */
	@Override
	public String[] getLogPackages() {
		return new String[] { "de.zbit", "org.sbml", "org.simulator", "eva" };
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getURLlicenseFile()
	 */
	public URL getURLlicenseFile() {
		URL url = null;
		try {
			url = new URL("http://www.gnu.org/licenses/lgpl-3.0-standalone.html");
		} catch (MalformedURLException exc) {
			logger.log(Level.FINER, exc.getLocalizedMessage(), exc);
		}
		return url;
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getURLOnlineUpdate()
	 */
	public URL getURLOnlineUpdate() {
		URL url = null;
		try {
			url = new URL("http://www.cogsys.cs.uni-tuebingen.de/software/SBMLsimulator/downloads/");
		} catch (MalformedURLException exc) {
			logger.log(Level.FINER, exc.getLocalizedMessage(), exc);
		}
		return url;
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getVersionNumber()
	 */
	public String getVersionNumber() {
		return "1.1";
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getYearOfProgramRelease()
	 */
	public short getYearOfProgramRelease() {
		return (short) 2013;
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#getYearWhenProjectWasStarted()
	 */
	public short getYearWhenProjectWasStarted() {
		return 2007;
	}

	/* (non-Javadoc)
	 * @see de.zbit.Launcher#initGUI(de.zbit.AppConf)
	 */
	public BaseFrame initGUI(AppConf appConf) {
		final BaseFrame gui = new SimulatorUI(appConf);
		if (getCmdLineOptions().contains(GarudaOptions.class)
				&& (!appConf.getCmdArgs().containsKey(GarudaOptions.CONNECT_TO_GARUDA) ||
						appConf.getCmdArgs().getBoolean(GarudaOptions.CONNECT_TO_GARUDA))) {
			new Thread(new Runnable() {
				/* (non-Javadoc)
				 * @see java.lang.Runnable#run()
				 */
				public void run() {
					try {
						String localPath = SBMLsimulator.class.getProtectionDomain().getCodeSource().getLocation().getPath();
						String folder = new File(localPath).getParent() + "/resources/org/sbml/simulator/gui/img/";
						String icon = folder + "SBMLsimulator_64.png";

						GarudaSoftwareBackend garudaBackend = new GarudaSoftwareBackend(
								"1cfbffa0-bbcb-4ca9-aa44-bfa4815e935e",
								(UserInterface) gui,
								icon,
								bundle.getString("PROGRAM_DESCRIPTION"),
								Arrays.asList(bundle.getStringArray("KEYWORDS")),
								Arrays.asList(new String[] { "snapshot/Screenshot_1.png" })
						);
						garudaBackend.addInputFileFormat("xml", "SBML");
						garudaBackend.addInputFileFormat("sbml", "SBML");
						garudaBackend.addInputFileFormat("csv", "Character-separated Value");
						garudaBackend.addInputFileFormat("txt", "Character-separated Value");
						garudaBackend.addOutputFileFormat("xml", "SBML");
						garudaBackend.addOutputFileFormat("sbml", "SBML");
						garudaBackend.addOutputFileFormat("csv", "Character-separated Value");
						garudaBackend.addOutputFileFormat("txt", "Character-separated Value");
						garudaBackend.init();
						garudaBackend.registedSoftwareToGaruda();
					} catch (NetworkException exc) {
						GUITools.showErrorMessage(gui, exc);
					} catch (BackendNotInitializedException exc) {
						GUITools.showErrorMessage(gui, exc);
					} catch (Throwable exc) {
						String message = exc.getLocalizedMessage();
						logger.log(Level.FINE, message != null ? message : exc.getMessage(), exc);
					}
				}
			}).start();
		}
		return gui;
	}

}
