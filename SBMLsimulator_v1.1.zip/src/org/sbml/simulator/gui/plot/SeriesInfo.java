/*
 * $Id: SeriesInfo.java 788 2013-01-04 11:46:00Z draeger $
 * $URL: https://rarepos.cs.uni-tuebingen.de/svn-path/SBMLsimulator/branches/1.0-series/src/org/sbml/simulator/gui/plot/SeriesInfo.java $
 * ---------------------------------------------------------------------
 * This file is part of SBMLsimulator, a Java-based simulator for models
 * of biochemical processes encoded in the modeling language SBML.
 *
 * Copyright (C) 2007-2013 by the University of Tuebingen, Germany.
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation. A copy of the license
 * agreement is provided in the file named "LICENSE.txt" included with
 * this software distribution and also available online as
 * <http://www.gnu.org/licenses/lgpl-3.0-standalone.html>.
 * ---------------------------------------------------------------------
 */
package org.sbml.simulator.gui.plot;

import java.awt.Paint;

/**
 * Stores information about a series for a plot.
 * 
 * @author Andreas Dr&auml;ger
 * @version $Rev: 788 $
 * @since 1.0
 */
public class SeriesInfo {
	
	private String id;
	private String name;
	private String tooltip;
	private Paint paint;
	
	public SeriesInfo() {
		super();
	}
	
	/**
	 * 
	 * @param id
	 * @param name
	 * @param tooltip
	 * @param paint
	 * @param connected
	 */
	public SeriesInfo(String id, String name, String tooltip, Paint paint) {
		this();
		this.id = id;
		this.name = name;
		this.tooltip = tooltip;
		this.paint = paint;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the tooltip
	 */
	public String getTooltip() {
		return tooltip;
	}

	/**
	 * @param tooltip the tooltip to set
	 */
	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}

	/**
	 * @return the paint
	 */
	public Paint getPaint() {
		return paint;
	}

	/**
	 * @param paint the paint to set
	 */
	public void setPaint(Paint paint) {
		this.paint = paint;
	}
	
}
